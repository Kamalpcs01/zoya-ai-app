
Zoya AI Assistant (APK Build Project)

HOW TO RUN:

1. Install Node.js
2. Install Expo CLI:
   npm install -g expo-cli

3. Install dependencies:
   npm install

4. Run project:
   npm start

5. To build APK:
   Use Expo EAS:
   npm install -g eas-cli
   eas build -p android

This is a demo AI assistant app with voice output.
