
import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from "react-native";
import * as Speech from "expo-speech";

export default function App() {
  const [messages, setMessages] = useState([
    { role: "bot", text: "Hi 👋 मैं Zoya AI हूँ 🤖" }
  ]);
  const [input, setInput] = useState("");

  const speak = (text) => {
    Speech.speak(text, { language: "hi-IN" });
  };

  const sendMessage = () => {
    if (!input.trim()) return;

    const userMsg = { role: "user", text: input };
    setMessages([...messages, userMsg]);
    setInput("");

    setTimeout(() => {
      const reply = "मैं अभी demo mode में हूँ 😊 (APK version)";
      setMessages((prev) => [...prev, { role: "bot", text: reply }]);
      speak(reply);
    }, 700);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Zoya AI Assistant 🤖</Text>

      <ScrollView style={styles.chat}>
        {messages.map((m, i) => (
          <View
            key={i}
            style={[
              styles.msg,
              m.role === "user" ? styles.user : styles.bot
            ]}
          >
            <Text style={{ color: m.role === "user" ? "#fff" : "#000" }}>
              {m.text}
            </Text>
          </View>
        ))}
      </ScrollView>

      <View style={styles.inputBox}>
        <TextInput
          value={input}
          onChangeText={setInput}
          placeholder="Type message..."
          style={styles.input}
        />

        <TouchableOpacity style={styles.btn} onPress={sendMessage}>
          <Text style={{ color: "#fff" }}>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 50 },
  header: { fontSize: 20, fontWeight: "bold", textAlign: "center" },
  chat: { flex: 1, padding: 10 },
  msg: { padding: 10, marginVertical: 5, borderRadius: 10, maxWidth: "80%" },
  user: { backgroundColor: "#4f46e5", alignSelf: "flex-end" },
  bot: { backgroundColor: "#e5e7eb", alignSelf: "flex-start" },
  inputBox: { flexDirection: "row", padding: 10 },
  input: { flex: 1, borderWidth: 1, borderRadius: 8, padding: 10 },
  btn: { backgroundColor: "#4f46e5", padding: 10, marginLeft: 5, borderRadius: 8 }
});
